# Import routines

import numpy as np
import math
import random
from itertools import product


# Defining hyperparameters
m = 5 # number of cities, ranges from 1 ..... m
t = 24 # number of hours, ranges from 0 .... t-1
d = 7  # number of days, ranges from 0 ... d-1
C = 5 # Per hour fuel and other costs
R = 9 # per hour revenue from a passenger

lamda_loc_A=2    #lambda for poisson distribution
lamda_loc_B=12
lamda_loc_C=4
lamda_loc_D=7
lamda_loc_E=8



class CabDriver():

    def __init__(self):
        """initialise your state and define your action space and state space"""
        self.action_space = [tup for tup in list(product(np.arange(0,m),np.arange(0,m))) if (tup[0]!=tup[1]) or (tup[0]==0 and tup[1]==0)]
        self.state_space = list(product(np.arange(0,m),np.arange(0,t),np.arange(0,d)))
        self.state_init =  self.state_space[np.random.choice(np.arange(0,len(self.state_space)))]
        self.steps=0
        # Start the first round
        self.reset()


    ## Encoding state (or state-action) for NN input

    def state_encod_arch1(self, state):
        """convert the state into a vector so that it can be fed to the NN. This method converts a given state into a vector format. Hint: The vector is of size m + t + d."""
        state_tmp=[0]*m
        time_tmp=[0]*t
        day_tmp=[0]*d
        state_tmp[state[0]]=1
        time_tmp[state[1]]=1
        day_tmp[state[2]]=1
        state_encod=state_tmp+time_tmp+day_tmp
        return state_encod


    # Use this function if you are using architecture-2 
    # def state_encod_arch2(self, state, action):
    #     """convert the (state-action) into a vector so that it can be fed to the NN. This method converts a given state-action pair into a vector format. Hint: The vector is of size m + t + d + m + m."""

        
    #     return state_encod


    ## Getting number of requests

    def requests(self, state):
        """Determining the number of requests basis the location. 
        Use the table specified in the MDP and complete for rest of the locations"""
        location = state[0]
        if location == 0:
            requests = np.random.poisson(lamda_loc_A)
        elif location == 1:
            requests = np.random.poisson(lamda_loc_B)
        elif location == 2:
            requests = np.random.poisson(lamda_loc_C)
        elif location == 3:
            requests = np.random.poisson(lamda_loc_D)
        elif location == 4:
            requests = np.random.poisson(lamda_loc_E)

        if requests >15:
            requests =15

        possible_actions_index = random.sample(range(1, (m-1)*m +1), requests) # (0,0) is not considered as customer request
        actions = [self.action_space[i] for i in possible_actions_index]

        
        actions.append([0,0])
        possible_actions_index.append(0)
        
        return possible_actions_index,actions   
    
    def time_offset_calc(self,currenttime,currentday,hoursoffset):
        nexttime=0
        nextday=0
        if (currenttime+hoursoffset)<24:
            nexttime=currenttime+hoursoffset
            nextday=currentday
        else:
            nexttime=(currenttime+hoursoffset)%24
            #@TODO to place next day as hoursoffset/24 to account for multiple days
            nextday=currentday+int((currenttime+hoursoffset)/24)
            #print("nextday...",nextday)
            nextday=nextday%7
        return int(nexttime),int(nextday)



    def reward_func(self, state, action, Time_matrix):
        """Takes in state, action and Time-matrix and returns the reward"""
        next_state=state
            
        if action[0]==0 and action[1]==0:   # no request is selected 
            reward=-1*C
       
        elif state[0]==action[0]:  # Pick up is same as current state
            time_pickup_drop=Time_matrix[action[0]][action[1]][state[1]][state[2]]
            reward=(R*time_pickup_drop)-(C*(time_pickup_drop))        
        
        else:                         # Pick up is different from current state
            # State transit for pickup
            time_start_pickup=Time_matrix[state[0]][action[0]][state[1]][state[2]]
            offset_time,offset_day=self.time_offset_calc(state[1],state[2],time_start_pickup)
            next_state=(action[0],offset_time,offset_day)
            
            # State transit for drop
            #print("next_state.....",next_state,time_start_pickup)
            time_pickup_drop=Time_matrix[action[0]][action[1]][next_state[1]][next_state[2]]
            offset_time,offset_day=self.time_offset_calc(next_state[1],next_state[2],time_pickup_drop)
            next_state=(action[1],offset_time,offset_day)
            
            reward=(R*time_pickup_drop)-(C*(time_start_pickup+time_pickup_drop))        
                        
            
        return reward
    

    

    def next_state_func(self, state, action, Time_matrix):
        """Takes state and action as input and returns next state"""
        next_state=state
        if action[0]==0 and action[1]==0:   # no request is selected 
            offset_time,offset_day=self.time_offset_calc(state[1],state[2],1)
            next_state=(state[0],offset_time,offset_day)
            
        elif state[0]==action[0]:  # Pick up is same as current state
            # State transit for drop
            offset_time,offset_day=self.time_offset_calc(state[1],state[2],Time_matrix[state[0]][action[1]][state[1]][state[2]])
            next_state=(action[1],offset_time,offset_day)
                
        else:                         # Pick up is different from current state
            # State transit for pickup
            offset_time,offset_day=self.time_offset_calc(state[1],state[2],Time_matrix[state[0]][action[0]][state[1]][state[2]])
            next_state=(action[0],offset_time,offset_day)

            # State transit for drop
            offset_time,offset_day=self.time_offset_calc(next_state[1],next_state[2],Time_matrix[action[0]][action[1]][next_state[1]][next_state[2]])
            next_state=(action[1],offset_time,offset_day)
        
        self.steps=self.steps+1
        isTerminal=False
        if self.steps>=24*30:
            print("Terminal")
            isTerminal=True
        
        return next_state,isTerminal




    def reset(self):
        return self.action_space, self.state_space, self.state_init
